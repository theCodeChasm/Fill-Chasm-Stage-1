//Christopher Albert
//Why was the math book sad? Because it had too many problems.


package com.coolapps.uppercase_;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;



public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button clearButton = findViewById(R.id.button2);
        Button uppercaseButton = findViewById(R.id.button);
        Button lowercaseButton = findViewById(R.id.button4);
        Button separate = findViewById(R.id.button3);
        clearButton.setOnClickListener(this);
        uppercaseButton.setOnClickListener(this);
        lowercaseButton.setOnClickListener(this);
        separate.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        EditText editText = findViewById(R.id.editText);
        editText.setOnClickListener(this);
        if (v == findViewById(R.id.button2)) {
editText.setText("");
        } else if (v == findViewById(R.id.button)) {
            String text = editText.getText().toString();
            text = text.toUpperCase(getResources().getConfiguration().locale);
            editText.setText(text);
        } else if (v == findViewById(R.id.button4)){
            String text = editText.getText().toString();
            text = text.toLowerCase(getResources().getConfiguration().locale);
            editText.setText(text);}
            else if(v == findViewById(R.id.button3)){
                String text = editText.getText().toString();
            String[] words = text.split(" ");
            for(int i=0;i<words.length;i++){
                editText.append("\n");
                editText.append(words[i]);

            }

            }
        }
    }