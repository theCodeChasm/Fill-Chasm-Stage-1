﻿/* Christopher Albert
 * CSCI 3005 Section 10
 * Program to simulate The Frog Hop Game
 * Assignment 1
 * September 3, 2018
 */

 using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChristopherAlbertAssignment01
{
    class FrogBuilder
    {
        private Frog frog; 

        public FrogBuilder()
        {
        frog = new Frog(" ", 0, 0);
        }
        
        public void buildFrog()
        {
            Console.WriteLine("What is the name of your frog?");
            string name = Console.ReadLine();
            
            Console.WriteLine("How many inches per hop can your frog travel?"   );
            decimal inchesPer = Convert.ToDecimal(Console.ReadLine());
           
            Console.WriteLine("How many hops per minute can your frog travel?");
            decimal hopsPer = Convert.ToDecimal(Console.ReadLine());
            frog = new Frog(name, inchesPer, hopsPer);

        }
        public Frog getFrog()
        {
            if (frog.getName() == " ")
                throw new NullReferenceException ("No frog exists");

            else
            return frog;
        }
        
        
    }
}
