﻿/* Christopher Albert
 * CSCI 3005 Section 10
 * Program to simulate The Frog Hop Game
 * Assignment 1
 * September 3, 2018
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChristopherAlbertAssignment01
{
    class Frog
    {
        private string name;
        private decimal inchesPerHop;
        private decimal hopsPerMinute;

        public Frog(string mname, decimal minchesPerHop, decimal mhopsPerMinute)
        {
            this.name = mname;
            this.inchesPerHop = minchesPerHop;
            this.hopsPerMinute = mhopsPerMinute;

        }

        public string getName()
        {
            return name;
        }

        public void setName(string mname)
        {
            this.name = mname;
        }

        public void setInchesPerHop(decimal inches)
        {
            this.inchesPerHop = inches;
        }

        public decimal getInchesPerHop()
        {
            return inchesPerHop;
        }

        public decimal getHopsperMinute()
        {
            return hopsPerMinute;
        }

        public void setHopsPerMinute(decimal hops)
        {
            this.hopsPerMinute = hops;
        }

        public decimal getTimeTraveled(decimal distance)
        {
            decimal time = distance / (inchesPerHop * hopsPerMinute);
            return time;
        }


    }
}
